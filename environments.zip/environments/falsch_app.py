from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = '425345!r33nf3'

# SQLite database connection
conn = sqlite3.connect('database.db')
conn.execute('PRAGMA foreign_keys = ON')
conn.commit()

# Helper function to execute database queries
def execute_query(query, params=()):
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    return cursor

# Check if the users table exists, and if not, create it
execute_query('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )
''')

# Check if the receipts table exists, and if not, create it
execute_query('''
    CREATE TABLE IF NOT EXISTS receipts (
        id INTEGER PRIMARY KEY,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        user_id INTEGER,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
''')

@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('home.html')

# ... (Ihre Routen f�r /login, /logout, /create_receipt, /view_receipts und /register bleiben unver�ndert) ...

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

if __name__ == '__main__':
    app.run(debug=True)

# F�gen Sie diese Zeile am Ende hinzu, um den Server auf 0.0.0.0 zu binden und auf externe Anfragen zu antworten.
if __name__ == "__main__":
    app.run(host='0.0.0.0')
