from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = '425345!r33nf3'

# SQLite database connection
conn = sqlite3.connect('database.db')
conn.execute('PRAGMA foreign_keys = ON')
conn.commit()

# Helper function to execute database queries
def execute_query(query, params=()):
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    return cursor

# Check if the users table exists, and if not, create it
execute_query('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )
''')

# Check if the receipts table exists, and if not, create it
execute_query('''
    CREATE TABLE IF NOT EXISTS receipts (
        id INTEGER PRIMARY KEY,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        user_id INTEGER,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
''')

@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = execute_query('SELECT * FROM users WHERE username = ?', (username,)).fetchone()

        if user and user[2] == password:  # Assuming the password is stored in the third column
            session['user_id'] = user[0]
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login failed. Please check your credentials.', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logout successful!', 'success')
    return redirect(url_for('login'))

@app.route('/create_receipt', methods=['GET', 'POST'])
def create_receipt():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        amount = request.form['amount']
        description = request.form['description']
        user_id = session['user_id']

        execute_query('INSERT INTO receipts (title, amount, description, user_id) VALUES (?, ?, ?, ?)', (title, amount, description, user_id))
        flash('Receipt created successfully!', 'success')
        return redirect(url_for('home'))

    return render_template('create_receipt.html')

#@app.route('/create_receipt', methods=['POST'])
#def create_receipt():
#    if 'user_id' not in session:
#        return redirect(url_for('login'))
#
#    if request.method == 'POST':
#        title = request.form['title']
#        amount = request.form['amount']
#        description = request.form['description']
#        user_id = session['user_id']  # Get the logged-in user's ID
#
#        # Insert the receipt into the database with the user's ID
#        execute_query('INSERT INTO receipts (title, amount, description, user_id) VALUES (?, ?, ?, ?)',
#                      (title, amount, description, user_id))
#        flash('Receipt created successfully!', 'success')
#        return redirect(url_for('view_receipts'))
#
#    return render_template('create_receipt.html')


@app.route('/view_receipts')
def view_receipts():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    receipts = execute_query('SELECT * FROM receipts WHERE user_id = ?', (user_id,)).fetchall()

    return render_template('view_receipts.html', receipts=receipts)

#@app.route('/view_receipts')
#def view_receipts():
#    if 'user_id' not in session:
#        return redirect(url_for('login'))

#    user_id = session['user_id']
#    receipts = execute_query('SELECT * FROM receipts WHERE user_id = ?', (user_id,)).fetchall()

#    return render_template('view_receipts.html', receipts=receipts)


#@app.route('/view_receipts')
#def view_receipts():
#    if 'user_id' not in session:
#        return redirect(url_for('login'))
#
#    user_id = session['user_id']
#    receipts = execute_query('SELECT * FROM receipts WHERE user_id = ?', (user_id,)).fetchall()
#
#    return render_template('view_receipts.html', receipts=receipts)
#

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username is already in use
        existing_user = execute_query('SELECT * FROM users WHERE username = ?', (username,)).fetchone()

        if existing_user:
            flash('Username is already in use. Please choose a different one.', 'danger')
        else:
            # Insert the new user into the database
            execute_query('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))

    return render_template('register.html')



if __name__ == '__main__':
    app.run(debug=True)


if __name__ == "__main__":
    app.run(host='0.0.0.0')
